In this project, I utilized two main functions besides void draw and void set up, which were void, apply filter and void blur. I made separate ones because for some reason I was having an issue with the blur function. It just kept looping and after trying and experimenting with a different redraw and no loop functions. I just decided to make it a separate function that would run on its own. I also utilized the  key pressed function, obviously, so the user could input different keys to make the filter appear on the original image with the help of loops I was able to properly get my function running. I also had to experiment with the draw function and kind of apply common sense in order to get my sobel filter to work properly because that was my last one that I was working on and it was giving me a lot of static which was making me itch initially. But luckily, I was able to figure that out.}

The filter displays over an image of Grammy award winner Harry Styles showcasing his 'Late Late' show tattoo.




